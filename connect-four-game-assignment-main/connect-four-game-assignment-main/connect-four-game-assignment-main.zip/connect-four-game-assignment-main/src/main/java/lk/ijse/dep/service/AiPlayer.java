
package lk.ijse.dep.service;

import java.util.Random;

public class AiPlayer extends Player {

    public AiPlayer(BoardImpl newBoard) {
        super(newBoard);
    }

    @Override
    public void movePiece(int col) {
        int a = setPiece();
        col = a;

        if (this.board.isLegalMove(col)) {
            this.board.updateMove(col,Piece.GREEN);
            this.board.getBoardUI().update(col, false);
            Winner winner = this.board.findWinner();

            if (winner == null) {
                boolean b = this.board.exitLegalMoves();
                if (!b) {
                    this.board.getBoardUI().notifyWinner(new Winner(Piece.EMPTY));
                }
            } else {
                this.board.getBoardUI().notifyWinner(winner);
            }
        }
    }
    public int setPiece(){
        Piece[][] pieces = board.getPieces();
        int num=0;
        for (int c = 0; c < 6; c++) {
            for(int r=0;r<5;r++){
                if (pieces[c][0]==Piece.BLUE && pieces[c][1]==Piece.BLUE && pieces[c][2]==Piece.BLUE && pieces[c][3] == Piece.EMPTY ) {
                    return c;
                }if (pieces[c][0]==Piece.GREEN && pieces[c][1]==Piece.GREEN  && pieces[c][2]==Piece.GREEN && pieces[c][3] == Piece.EMPTY ) {
                    return c;
                }else if (pieces[0][r]==Piece.BLUE && pieces[1][r]==Piece.BLUE  &&  pieces[2][r] == Piece.EMPTY ) {
                    return 2;
                } else if (pieces[3][r]==Piece.BLUE && pieces[4][r]==Piece.BLUE  &&  pieces[5][r] == Piece.EMPTY ) {
                    return 5;
                }else if (pieces[0][r]==Piece.GREEN && pieces[1][r]==Piece.GREEN  &&  pieces[2][r] == Piece.EMPTY ) {
                    return 2;
                } else if (pieces[3][r]==Piece.GREEN && pieces[4][r]==Piece.GREEN  &&  pieces[5][r] == Piece.EMPTY ) {
                    return 5;
                } else{
                    do {
                        Random random = new Random();
                        num = random.nextInt(6);
                    } while (!this.board.isLegalMove(num));
                }
            }
        }
        return num;
    }
}